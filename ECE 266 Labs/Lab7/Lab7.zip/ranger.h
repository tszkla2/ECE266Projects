#ifndef RANGER_H_
#define RANGER_H_

// Initialize the motion detector
void rangerInit();

//Function for detecting
uint16_t rangerGet();

#endif // RANGER_H_INCLUDED
