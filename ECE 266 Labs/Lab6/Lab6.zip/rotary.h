#ifndef ROTARY_H_
#define ROTARY_H_

// Initialize the motion detector
void rotaryInit();

//Function for detecting
uint16_t rotaryGet();

#endif // MOTION_H_INCLUDED
